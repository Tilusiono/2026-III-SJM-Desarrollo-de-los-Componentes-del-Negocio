﻿$ErrorActionPreference = 'Stop'
Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing
[System.Windows.Forms.Application]::EnableVisualStyles()

Add-Type @"
using System;
using System.Runtime.InteropServices;
public static class EnvironmentBroadcast {
    [DllImport("user32.dll", SetLastError=true, CharSet=CharSet.Auto)]
    public static extern IntPtr SendMessageTimeout(
        IntPtr hWnd, uint Msg, UIntPtr wParam, string lParam,
        uint fuFlags, uint uTimeout, out UIntPtr lpdwResult);
}
"@

$AppName = 'Java Home Manager'
$DefaultJavaRoot = 'C:\Program Files\Java'
$DataFolder = Join-Path $env:LOCALAPPDATA 'JavaHomeManager'
$RegistryFile = Join-Path $DataFolder 'versions.json'
$script:Entries = @()

function Show-Info([string]$message) {
    [System.Windows.Forms.MessageBox]::Show(
        $message, $AppName,
        [System.Windows.Forms.MessageBoxButtons]::OK,
        [System.Windows.Forms.MessageBoxIcon]::Information
    ) | Out-Null
}

function Show-Error([string]$message) {
    [System.Windows.Forms.MessageBox]::Show(
        $message, $AppName,
        [System.Windows.Forms.MessageBoxButtons]::OK,
        [System.Windows.Forms.MessageBoxIcon]::Error
    ) | Out-Null
}

function Confirm([string]$message) {
    return [System.Windows.Forms.MessageBox]::Show(
        $message, $AppName,
        [System.Windows.Forms.MessageBoxButtons]::YesNo,
        [System.Windows.Forms.MessageBoxIcon]::Question
    ) -eq [System.Windows.Forms.DialogResult]::Yes
}

function Is-Administrator {
    $identity = [Security.Principal.WindowsIdentity]::GetCurrent()
    $principal = New-Object Security.Principal.WindowsPrincipal($identity)
    return $principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
}

function Get-Target {
    if ($scopeCombo.SelectedItem -eq 'Sistema') {
        return [EnvironmentVariableTarget]::Machine
    }
    return [EnvironmentVariableTarget]::User
}

function Assert-TargetPermission {
    if ((Get-Target) -eq [EnvironmentVariableTarget]::Machine -and -not (Is-Administrator)) {
        throw 'Para modificar variables del sistema debes ejecutar la aplicación como administrador.'
    }
}

function Normalize-PathEntry([string]$value) {
    if ([string]::IsNullOrWhiteSpace($value)) { return '' }
    return (($value.Trim().Trim('"') -replace '/', '\').TrimEnd('\'))
}

function Test-JavaPathToken([EnvironmentVariableTarget]$target) {
    $current = [Environment]::GetEnvironmentVariable('Path', $target)
    if ([string]::IsNullOrWhiteSpace($current)) { return $false }
    $wanted = Normalize-PathEntry '%JAVA_HOME%\bin'
    foreach ($entry in ($current -split ';')) {
        if ((Normalize-PathEntry $entry) -ieq $wanted) { return $true }
    }
    return $false
}

function Get-JavaPathTokenPosition([EnvironmentVariableTarget]$target) {
    $current = [Environment]::GetEnvironmentVariable('Path', $target)
    if ([string]::IsNullOrWhiteSpace($current)) { return 0 }
    $wanted = Normalize-PathEntry '%JAVA_HOME%\bin'
    $position = 0
    foreach ($entry in ($current -split ';')) {
        if ([string]::IsNullOrWhiteSpace($entry)) { continue }
        $position++
        if ((Normalize-PathEntry $entry) -ieq $wanted) { return $position }
    }
    return 0
}

function Ensure-JavaPathToken([EnvironmentVariableTarget]$target) {
    $current = [Environment]::GetEnvironmentVariable('Path', $target)
    $token = '%JAVA_HOME%\bin'
    $wanted = Normalize-PathEntry $token
    $oldPosition = Get-JavaPathTokenPosition $target
    if ($oldPosition -eq 1) { return 'unchanged' }
    $entries = @()
    if (-not [string]::IsNullOrWhiteSpace($current)) {
        $entries = @($current -split ';' | Where-Object {
            -not [string]::IsNullOrWhiteSpace($_) -and
            (Normalize-PathEntry $_) -ine $wanted
        })
    }
    $updated = (@($token) + $entries) -join ';'
    [Environment]::SetEnvironmentVariable('Path', $updated, $target)
    if ($oldPosition -eq 1) { return 'unchanged' }
    if ($oldPosition -gt 1) { return 'moved' }
    return 'added'
}

function Broadcast-EnvironmentChange {
    $result = [UIntPtr]::Zero
    [EnvironmentBroadcast]::SendMessageTimeout(
        [IntPtr]0xffff, 0x001A, [UIntPtr]::Zero, 'Environment',
        0x0002, 5000, [ref]$result
    ) | Out-Null
}

function Get-JavaMetadata([string]$folder) {
    $javaExe = Join-Path $folder 'bin\java.exe'
    $javacExe = Join-Path $folder 'bin\javac.exe'
    if (-not (Test-Path -LiteralPath $javaExe -PathType Leaf)) {
        throw "La carpeta no contiene bin\java.exe:`n$folder"
    }

    $version = ''
    $releaseFile = Join-Path $folder 'release'
    if (Test-Path -LiteralPath $releaseFile) {
        $match = Select-String -LiteralPath $releaseFile -Pattern '^JAVA_VERSION="([^"]+)"' |
            Select-Object -First 1
        if ($match -and $match.Matches.Count -gt 0) {
            $version = $match.Matches[0].Groups[1].Value
        }
    }
    if ([string]::IsNullOrWhiteSpace($version)) {
        $versionResult = Invoke-NativeCommand $javaExe '-version'
        $output = $versionResult.Output
        if ($output -match 'version\s+"([^"]+)"') { $version = $Matches[1] }
    }
    if ([string]::IsNullOrWhiteSpace($version)) {
        $version = Split-Path $folder -Leaf
    }

    [PSCustomObject]@{
        Version = $version
        Type = if (Test-Path -LiteralPath $javacExe) { 'JDK' } else { 'JRE' }
        Path = [IO.Path]::GetFullPath($folder).TrimEnd('\')
        Source = 'Detectada'
    }
}

function Load-SavedEntries {
    if (-not (Test-Path -LiteralPath $RegistryFile)) { return @() }
    try {
        $raw = Get-Content -LiteralPath $RegistryFile -Raw -Encoding UTF8
        if ([string]::IsNullOrWhiteSpace($raw)) { return @() }
        return @($raw | ConvertFrom-Json)
    } catch {
        Show-Error "No se pudo leer el registro guardado.`n$($_.Exception.Message)"
        return @()
    }
}

function Save-Entries {
    if (-not (Test-Path -LiteralPath $DataFolder)) {
        New-Item -ItemType Directory -Path $DataFolder -Force | Out-Null
    }
    @($script:Entries |
        Where-Object { $_.Source -eq 'Registrada' } |
        Select-Object Version, Type, Path, Source) |
        ConvertTo-Json -Depth 3 |
        Set-Content -LiteralPath $RegistryFile -Encoding UTF8
}

function Add-OrUpdateEntry($entry, [bool]$registered) {
    $path = [string]$entry.Path
    $existing = @($script:Entries | Where-Object { $_.Path -ieq $path }) | Select-Object -First 1
    if ($existing) {
        $existing.Version = [string]$entry.Version
        $existing.Type = [string]$entry.Type
        if ($registered) { $existing.Source = 'Registrada' }
    } else {
        $script:Entries += [PSCustomObject]@{
            Version = [string]$entry.Version
            Type = [string]$entry.Type
            Path = $path
            Source = if ($registered) { 'Registrada' } else { [string]$entry.Source }
        }
    }
}

function Refresh-Grid {
    $target = Get-Target
    $active = [Environment]::GetEnvironmentVariable('JAVA_HOME', $target)
    $grid.Rows.Clear()
    foreach ($entry in ($script:Entries | Sort-Object Version, Path)) {
        $activeText = if ((Normalize-PathEntry $entry.Path) -ieq (Normalize-PathEntry $active)) { 'Sí' } else { '' }
        [void]$grid.Rows.Add($entry.Version, $entry.Type, $entry.Path, $entry.Source, $activeText)
    }
    $homeText.Text = if ($active) { $active } else { '(no configurado)' }
    $pathPosition = Get-JavaPathTokenPosition $target
    $pathText.Text = if ($pathPosition -gt 0) {
        "%JAVA_HOME%\bin está registrado en Path, posición $pathPosition"
    } else {
        '%JAVA_HOME%\bin todavía no existe en Path'
    }
    $pathText.ForeColor = if (Test-JavaPathToken $target) {
        [Drawing.Color]::FromArgb(34,197,94)
    } else {
        [Drawing.Color]::FromArgb(245,158,11)
    }
}

function Scan-JavaFolders {
    if (-not (Test-Path -LiteralPath $DefaultJavaRoot -PathType Container)) {
        Show-Error "No se encontró la carpeta:`n$DefaultJavaRoot"
        return
    }
    $count = 0
    foreach ($folder in (Get-ChildItem -LiteralPath $DefaultJavaRoot -Directory -ErrorAction SilentlyContinue)) {
        if (Test-Path -LiteralPath (Join-Path $folder.FullName 'bin\java.exe')) {
            try {
                Add-OrUpdateEntry (Get-JavaMetadata $folder.FullName) $false
                $count++
            } catch {}
        }
    }
    Refresh-Grid
    $statusLabel.Text = "Se detectaron $count instalaciones en $DefaultJavaRoot"
}

function Register-Folder {
    try {
        Assert-TargetPermission
        $dialog = New-Object System.Windows.Forms.FolderBrowserDialog
        $dialog.Description = 'Selecciona la carpeta raíz del JDK o JRE'
        $dialog.SelectedPath = $DefaultJavaRoot
        $dialog.ShowNewFolderButton = $false
        if ($dialog.ShowDialog() -ne [System.Windows.Forms.DialogResult]::OK) { return }

        $entry = Get-JavaMetadata $dialog.SelectedPath
        if ($entry.Type -eq 'JRE' -and -not (Confirm "La carpeta corresponde a un JRE y no incluye javac.exe.`n¿Deseas registrarla de todos modos?")) {
            return
        }
        Add-OrUpdateEntry $entry $true
        Save-Entries
        $pathAction = Ensure-JavaPathToken (Get-Target)
        Broadcast-EnvironmentChange
        Refresh-Grid
        $pathResult = switch ($pathAction) {
            'added' { 'Se agregó %JAVA_HOME%\bin al inicio de Path.' }
            'moved' { 'La entrada existente %JAVA_HOME%\bin se movió al inicio de Path.' }
            default { '%JAVA_HOME%\bin ya estaba al inicio de Path.' }
        }
        Show-Info "Versión registrada: $($entry.Version)`nRuta: $($entry.Path)`n`n$pathResult"
        $statusLabel.Text = 'Versión registrada correctamente'
    } catch {
        Show-Error $_.Exception.Message
    }
}

function Get-SelectedEntry {
    if ($grid.SelectedRows.Count -eq 0) {
        Show-Info 'Selecciona una versión de la lista.'
        return $null
    }
    $selectedPath = [string]$grid.SelectedRows[0].Cells['Path'].Value
    return @($script:Entries | Where-Object { $_.Path -ieq $selectedPath }) | Select-Object -First 1
}

function Activate-Selected {
    try {
        Assert-TargetPermission
        $entry = Get-SelectedEntry
        if (-not $entry) { return }
        if (-not (Test-Path -LiteralPath (Join-Path $entry.Path 'bin\java.exe'))) {
            throw "La instalación ya no existe o no contiene bin\java.exe:`n$($entry.Path)"
        }
        if ($entry.Type -eq 'JRE' -and -not (Confirm "Seleccionaste un JRE. Algunas herramientas de desarrollo necesitan un JDK.`n¿Deseas continuar?")) {
            return
        }

        Add-OrUpdateEntry $entry $true
        Save-Entries
        $target = Get-Target
        [Environment]::SetEnvironmentVariable('JAVA_HOME', $entry.Path, $target)
        $verifiedHome = [Environment]::GetEnvironmentVariable('JAVA_HOME', $target)
        if ((Normalize-PathEntry $verifiedHome) -ine (Normalize-PathEntry $entry.Path)) {
            throw 'Windows no confirmó el cambio de JAVA_HOME.'
        }
        $pathAction = Ensure-JavaPathToken $target
        if ((Get-JavaPathTokenPosition $target) -ne 1) {
            throw 'Windows no confirmó %JAVA_HOME%\bin en la primera posición de Path.'
        }

        $env:JAVA_HOME = $entry.Path
        $bin = Join-Path $entry.Path 'bin'
        $processEntries = @($env:Path -split ';')
        if (-not ($processEntries | Where-Object { (Normalize-PathEntry $_) -ieq (Normalize-PathEntry $bin) })) {
            $env:Path = $bin + ';' + $env:Path
        }
        Broadcast-EnvironmentChange
        Refresh-Grid

        $pathResult = switch ($pathAction) {
            'added' { 'Se agregó %JAVA_HOME%\bin al inicio de Path.' }
            'moved' { 'La entrada existente %JAVA_HOME%\bin se movió al inicio de Path.' }
            default { '%JAVA_HOME%\bin ya estaba al inicio de Path.' }
        }
        Show-Info "JAVA_HOME actualizado:`n$($entry.Path)`n`n$pathResult`n`nCierra y vuelve a abrir la ventana de Variables de entorno y cualquier terminal para ver el cambio."
        $statusLabel.Text = "JAVA_HOME activo: $($entry.Version)"
    } catch {
        Show-Error $_.Exception.Message
    }
}

function Remove-Selected {
    $entry = Get-SelectedEntry
    if (-not $entry) { return }
    if (-not (Confirm "¿Deseas quitar esta ruta del registro de la aplicación?`n`n$($entry.Path)`n`nNo se eliminará la carpeta de Java.")) {
        return
    }
    $script:Entries = @($script:Entries | Where-Object { $_.Path -ine $entry.Path })
    Save-Entries
    Refresh-Grid
    $statusLabel.Text = 'Registro eliminado. La instalación de Java no fue modificada.'
}

function Invoke-NativeCommand([string]$fileName, [string]$arguments) {
    try {
        $startInfo = New-Object System.Diagnostics.ProcessStartInfo
        $startInfo.FileName = $fileName
        $startInfo.Arguments = $arguments
        $startInfo.UseShellExecute = $false
        $startInfo.CreateNoWindow = $true
        $startInfo.RedirectStandardOutput = $true
        $startInfo.RedirectStandardError = $true

        $process = New-Object System.Diagnostics.Process
        $process.StartInfo = $startInfo
        [void]$process.Start()
        $standardOutput = $process.StandardOutput.ReadToEnd().Trim()
        $standardError = $process.StandardError.ReadToEnd().Trim()
        $process.WaitForExit()

        $lines = @()
        if (-not [string]::IsNullOrWhiteSpace($standardOutput)) { $lines += $standardOutput }
        if (-not [string]::IsNullOrWhiteSpace($standardError)) { $lines += $standardError }
        $combinedOutput = if ($lines.Count -gt 0) { $lines -join "`r`n" } else { '(sin salida)' }

        return [PSCustomObject]@{
            FileName = $fileName
            Arguments = $arguments
            ExitCode = $process.ExitCode
            StandardOutput = $standardOutput
            StandardError = $standardError
            Output = $combinedOutput
            Started = $true
        }
    } catch {
        return [PSCustomObject]@{
            FileName = $fileName
            Arguments = $arguments
            ExitCode = -1
            StandardOutput = ''
            StandardError = $_.Exception.Message
            Output = "No se pudo ejecutar: $($_.Exception.Message)"
            Started = $false
        }
    }
}

function Get-VersionMajor([string]$value) {
    if ([string]::IsNullOrWhiteSpace($value)) { return '' }
    if ($value -match '^1\.8') { return '8' }
    if ($value -match '^(\d+)') { return $Matches[1] }
    return ''
}

function Show-ValidationWindow([string]$report, [bool]$isValid, [string]$summary) {
    $validationForm = New-Object System.Windows.Forms.Form
    $validationForm.Text = 'Validación de Java'
    $validationForm.StartPosition = 'CenterParent'
    $validationForm.Size = New-Object Drawing.Size(900,690)
    $validationForm.MinimumSize = New-Object Drawing.Size(760,580)
    $validationForm.BackColor = [Drawing.Color]::FromArgb(12,12,15)
    $validationForm.ForeColor = [Drawing.Color]::White
    $validationForm.Font = New-Object Drawing.Font('Segoe UI',10)

    $validationTitle = New-Object System.Windows.Forms.Label
    $validationTitle.Text = if ($isValid) { 'Configuración válida' } else { 'Configuración con observaciones' }
    $validationTitle.Font = New-Object Drawing.Font('Segoe UI Semibold',20)
    $validationTitle.ForeColor = if ($isValid) {
        [Drawing.Color]::FromArgb(34,197,94)
    } else {
        [Drawing.Color]::FromArgb(245,158,11)
    }
    $validationTitle.AutoSize = $true
    $validationTitle.Location = New-Object Drawing.Point(24,18)
    $validationForm.Controls.Add($validationTitle)

    $validationSummary = New-Object System.Windows.Forms.Label
    $validationSummary.Text = $summary
    $validationSummary.ForeColor = [Drawing.Color]::FromArgb(190,190,200)
    $validationSummary.Location = New-Object Drawing.Point(27,62)
    $validationSummary.Size = New-Object Drawing.Size(820,42)
    $validationSummary.Anchor = 'Top,Left,Right'
    $validationForm.Controls.Add($validationSummary)

    $reportBox = New-Object System.Windows.Forms.RichTextBox
    $reportBox.Text = $report
    $reportBox.ReadOnly = $true
    $reportBox.WordWrap = $false
    $reportBox.BackColor = [Drawing.Color]::FromArgb(24,24,29)
    $reportBox.ForeColor = [Drawing.Color]::FromArgb(225,225,230)
    $reportBox.BorderStyle = 'None'
    $reportBox.Font = New-Object Drawing.Font('Consolas',10)
    $reportBox.Location = New-Object Drawing.Point(28,112)
    $reportBox.Size = New-Object Drawing.Size(825,475)
    $reportBox.Anchor = 'Top,Bottom,Left,Right'
    $validationForm.Controls.Add($reportBox)

    $copyButton = New-Object System.Windows.Forms.Button
    $copyButton.Text = 'Copiar resultado'
    $copyButton.Location = New-Object Drawing.Point(572,602)
    $copyButton.Size = New-Object Drawing.Size(160,38)
    $copyButton.Anchor = 'Bottom,Right'
    $copyButton.FlatStyle = 'Flat'
    $copyButton.FlatAppearance.BorderSize = 0
    $copyButton.BackColor = [Drawing.Color]::FromArgb(86,5,145)
    $copyButton.ForeColor = [Drawing.Color]::White
    $copyButton.Add_Click({
        [Windows.Forms.Clipboard]::SetText($reportBox.Text)
        $copyButton.Text = 'Resultado copiado'
    })
    $validationForm.Controls.Add($copyButton)

    $closeButton = New-Object System.Windows.Forms.Button
    $closeButton.Text = 'Cerrar'
    $closeButton.Location = New-Object Drawing.Point(742,602)
    $closeButton.Size = New-Object Drawing.Size(110,38)
    $closeButton.Anchor = 'Bottom,Right'
    $closeButton.FlatStyle = 'Flat'
    $closeButton.FlatAppearance.BorderSize = 0
    $closeButton.BackColor = [Drawing.Color]::FromArgb(55,55,65)
    $closeButton.ForeColor = [Drawing.Color]::White
    $closeButton.Add_Click({ $validationForm.Close() })
    $validationForm.Controls.Add($closeButton)

    [void]$validationForm.ShowDialog($form)
}

function Validate-JavaConfiguration {
    try {
        $target = Get-Target
        $scopeName = [string]$scopeCombo.SelectedItem
        $javaHome = [Environment]::GetEnvironmentVariable('JAVA_HOME', $target)
        $pathPosition = Get-JavaPathTokenPosition $target

        if ([string]::IsNullOrWhiteSpace($javaHome)) {
            Show-ValidationWindow "ALCANCE: $scopeName`r`nJAVA_HOME: (no configurado)" $false 'Configura JAVA_HOME antes de ejecutar la validación.'
            return
        }

        $expectedJava = Join-Path $javaHome 'bin\java.exe'
        $expectedJavac = Join-Path $javaHome 'bin\javac.exe'
        $javaExists = Test-Path -LiteralPath $expectedJava -PathType Leaf
        $javacExists = Test-Path -LiteralPath $expectedJavac -PathType Leaf

        $env:JAVA_HOME = $javaHome
        $whereResult = Invoke-NativeCommand 'where.exe' 'java'
        $javaResult = Invoke-NativeCommand 'java.exe' '-version'
        $javacResult = Invoke-NativeCommand 'javac.exe' '-version'
        $whereJava = $whereResult.Output
        $javaVersion = $javaResult.Output
        $javacVersion = $javacResult.Output
        try {
            $commandJava = (Get-Command java.exe -ErrorAction Stop).Source
        } catch {
            $commandJava = "No disponible: $($_.Exception.Message)"
        }

        $whereLines = @($whereJava -split "`r?`n" | Where-Object {
            -not [string]::IsNullOrWhiteSpace($_) -and $_ -notmatch '^No se pudo ejecutar:'
        })
        $firstJava = if ($whereLines.Count -gt 0) { $whereLines[0].Trim() } else { '' }
        $pathMatches = (Normalize-PathEntry $firstJava) -ieq (Normalize-PathEntry $expectedJava)

        $metadata = if ($javaExists) { Get-JavaMetadata $javaHome } else { $null }
        $expectedVersion = if ($metadata) { [string]$metadata.Version } else { '(desconocida)' }
        $expectedMajor = Get-VersionMajor $expectedVersion
        $versionMatches = if ([string]::IsNullOrWhiteSpace($expectedMajor)) {
            $false
        } elseif ($expectedMajor -eq '8') {
            $javaVersion -match 'version\s+"1\.8'
        } else {
            $javaVersion -match ('version\s+"' + [regex]::Escape($expectedMajor) + '(\.|")')
        }

        $isJdk = $javacExists
        $valid = $javaExists -and $pathMatches -and $versionMatches -and
            ($pathPosition -eq 1) -and ($whereResult.ExitCode -eq 0) -and
            ($javaResult.ExitCode -eq 0)
        if ($isJdk) {
            $valid = $valid -and ($javacResult.ExitCode -eq 0)
        }

        $checks = @(
            "JAVA_HOME existe       : $(if ($javaExists) { 'OK' } else { 'ERROR' })",
            "Path en posición 1     : $(if ($pathPosition -eq 1) { 'OK' } else { 'ERROR' })",
            "where java coincide    : $(if ($pathMatches) { 'OK' } else { 'ERROR' })",
            "java -version coincide : $(if ($versionMatches) { 'OK' } else { 'ERROR' })",
            "Código java -version   : $($javaResult.ExitCode)",
            "Compilador javac       : $(if ($isJdk -and $javacResult.ExitCode -eq 0) { 'OK' } elseif (-not $isJdk) { 'NO DISPONIBLE: es un JRE' } else { 'ERROR' })"
        ) -join "`r`n"

        $report = @"
RESULTADO GENERAL
-----------------
$checks

CONFIGURACIÓN
-------------
Alcance              : $scopeName
JAVA_HOME             : $javaHome
Versión esperada      : $expectedVersion
Tipo                  : $(if ($isJdk) { 'JDK' } else { 'JRE' })
Posición en Path      : $(if ($pathPosition -gt 0) { $pathPosition } else { 'No registrada' })
Java esperado         : $expectedJava
Java ejecutado        : $firstJava
Get-Command java      : $commandJava

WHERE JAVA
----------
$whereJava

JAVA -VERSION
-------------
$($javaResult.FileName) $($javaResult.Arguments)
Código de salida: $($javaResult.ExitCode)
$javaVersion

JAVAC -VERSION
--------------
$($javacResult.FileName) $($javacResult.Arguments)
Código de salida: $($javacResult.ExitCode)
$javacVersion

RECOMENDACIÓN
-------------
$(if ($valid) {
    'La configuración es correcta. Abre una terminal nueva para trabajar.'
} else {
    'Revisa los puntos marcados como ERROR. Puedes volver a activar la versión seleccionada y repetir esta validación.'
})
"@

        $summary = if ($valid) {
            "JAVA_HOME, Path y la versión ejecutada corresponden a Java $expectedVersion."
        } else {
            'Uno o más valores no corresponden a la instalación configurada.'
        }
        Show-ValidationWindow $report $valid $summary
        $statusLabel.Text = if ($valid) { 'Validación correcta' } else { 'Validación con observaciones' }
    } catch {
        Show-Error "No se pudo completar la validación.`n$($_.Exception.Message)"
    }
}

$form = New-Object System.Windows.Forms.Form
$form.Text = $AppName
$form.StartPosition = 'CenterScreen'
$form.Size = New-Object Drawing.Size(1040,680)
$form.MinimumSize = New-Object Drawing.Size(940,600)
$form.BackColor = [Drawing.Color]::FromArgb(12,12,15)
$form.ForeColor = [Drawing.Color]::White
$form.Font = New-Object Drawing.Font('Segoe UI',10)

$title = New-Object System.Windows.Forms.Label
$title.Text = 'Administrador de versiones de Java'
$title.Font = New-Object Drawing.Font('Segoe UI Semibold',20)
$title.AutoSize = $true
$title.Location = New-Object Drawing.Point(28,20)
$form.Controls.Add($title)

$subtitle = New-Object System.Windows.Forms.Label
$subtitle.Text = 'Registro de instalaciones, JAVA_HOME y Path'
$subtitle.ForeColor = [Drawing.Color]::FromArgb(185,185,195)
$subtitle.AutoSize = $true
$subtitle.Location = New-Object Drawing.Point(31,59)
$form.Controls.Add($subtitle)

$scopeLabel = New-Object System.Windows.Forms.Label
$scopeLabel.Text = 'Alcance:'
$scopeLabel.AutoSize = $true
$scopeLabel.Location = New-Object Drawing.Point(740,31)
$form.Controls.Add($scopeLabel)

$scopeCombo = New-Object System.Windows.Forms.ComboBox
$scopeCombo.DropDownStyle = 'DropDownList'
$scopeCombo.Items.AddRange(@('Sistema','Usuario'))
$scopeCombo.SelectedIndex = 0
$scopeCombo.Location = New-Object Drawing.Point(810,27)
$scopeCombo.Size = New-Object Drawing.Size(170,30)
$form.Controls.Add($scopeCombo)

$grid = New-Object System.Windows.Forms.DataGridView
$grid.Location = New-Object Drawing.Point(30,105)
$grid.Size = New-Object Drawing.Size(950,350)
$grid.Anchor = 'Top,Bottom,Left,Right'
$grid.BackgroundColor = [Drawing.Color]::FromArgb(24,24,29)
$grid.BorderStyle = 'None'
$grid.ReadOnly = $true
$grid.AllowUserToAddRows = $false
$grid.AllowUserToDeleteRows = $false
$grid.MultiSelect = $false
$grid.SelectionMode = 'FullRowSelect'
$grid.RowHeadersVisible = $false
$grid.AutoSizeRowsMode = 'AllCells'
$grid.EnableHeadersVisualStyles = $false
$grid.ColumnHeadersDefaultCellStyle.BackColor = [Drawing.Color]::FromArgb(86,5,145)
$grid.ColumnHeadersDefaultCellStyle.ForeColor = [Drawing.Color]::White
$grid.ColumnHeadersDefaultCellStyle.Font = New-Object Drawing.Font('Segoe UI Semibold',10)
$grid.DefaultCellStyle.BackColor = [Drawing.Color]::FromArgb(30,30,36)
$grid.DefaultCellStyle.ForeColor = [Drawing.Color]::White
$grid.DefaultCellStyle.SelectionBackColor = [Drawing.Color]::FromArgb(86,5,145)
$grid.DefaultCellStyle.SelectionForeColor = [Drawing.Color]::White
$grid.AlternatingRowsDefaultCellStyle.BackColor = [Drawing.Color]::FromArgb(36,36,43)

[void]$grid.Columns.Add('Version','Versión')
[void]$grid.Columns.Add('Type','Tipo')
[void]$grid.Columns.Add('Path','Ruta')
[void]$grid.Columns.Add('Source','Origen')
[void]$grid.Columns.Add('Active','Activa')
$grid.Columns['Version'].Width = 120
$grid.Columns['Type'].Width = 70
$grid.Columns['Path'].AutoSizeMode = 'Fill'
$grid.Columns['Source'].Width = 110
$grid.Columns['Active'].Width = 70
$form.Controls.Add($grid)

function New-Button([string]$textValue,[int]$x,[int]$width,[Drawing.Color]$color) {
    $button = New-Object System.Windows.Forms.Button
    $button.Text = $textValue
    $button.Location = New-Object Drawing.Point($x,475)
    $button.Size = New-Object Drawing.Size($width,42)
    $button.FlatStyle = 'Flat'
    $button.FlatAppearance.BorderSize = 0
    $button.BackColor = $color
    $button.ForeColor = [Drawing.Color]::White
    $button.Font = New-Object Drawing.Font('Segoe UI Semibold',10)
    $button.Anchor = 'Bottom,Left'
    $form.Controls.Add($button)
    return $button
}

$scanButton = New-Button 'Escanear Java' 30 165 ([Drawing.Color]::FromArgb(55,55,65))
$registerButton = New-Button 'Registrar carpeta' 210 190 ([Drawing.Color]::FromArgb(86,5,145))
$activateButton = New-Button 'Activar JAVA_HOME' 415 210 ([Drawing.Color]::FromArgb(34,197,94))
$removeButton = New-Button 'Quitar registro' 640 165 ([Drawing.Color]::FromArgb(70,70,80))
$validateButton = New-Button 'Validar versión' 820 160 ([Drawing.Color]::FromArgb(37,99,235))

$infoPanel = New-Object System.Windows.Forms.Panel
$infoPanel.Location = New-Object Drawing.Point(30,535)
$infoPanel.Size = New-Object Drawing.Size(950,72)
$infoPanel.Anchor = 'Bottom,Left,Right'
$infoPanel.BackColor = [Drawing.Color]::FromArgb(24,24,29)
$form.Controls.Add($infoPanel)

$homeLabel = New-Object System.Windows.Forms.Label
$homeLabel.Text = 'JAVA_HOME actual:'
$homeLabel.Font = New-Object Drawing.Font('Segoe UI Semibold',9)
$homeLabel.AutoSize = $true
$homeLabel.Location = New-Object Drawing.Point(15,11)
$infoPanel.Controls.Add($homeLabel)

$homeText = New-Object System.Windows.Forms.Label
$homeText.AutoEllipsis = $true
$homeText.ForeColor = [Drawing.Color]::FromArgb(190,190,200)
$homeText.Location = New-Object Drawing.Point(145,10)
$homeText.Size = New-Object Drawing.Size(770,22)
$infoPanel.Controls.Add($homeText)

$pathText = New-Object System.Windows.Forms.Label
$pathText.Location = New-Object Drawing.Point(15,40)
$pathText.Size = New-Object Drawing.Size(900,22)
$infoPanel.Controls.Add($pathText)

$statusLabel = New-Object System.Windows.Forms.Label
$statusLabel.Text = 'Listo'
$statusLabel.ForeColor = [Drawing.Color]::FromArgb(185,185,195)
$statusLabel.AutoSize = $true
$statusLabel.Location = New-Object Drawing.Point(30,615)
$statusLabel.Size = New-Object Drawing.Size(950,22)
$statusLabel.Anchor = 'Bottom,Left,Right'
$form.Controls.Add($statusLabel)

$scanButton.Add_Click({ Scan-JavaFolders })
$registerButton.Add_Click({ Register-Folder })
$activateButton.Add_Click({ Activate-Selected })
$removeButton.Add_Click({ Remove-Selected })
$validateButton.Add_Click({ Validate-JavaConfiguration })
$scopeCombo.Add_SelectedIndexChanged({ Refresh-Grid })
$grid.Add_CellDoubleClick({ Activate-Selected })

foreach ($entry in (Load-SavedEntries)) { Add-OrUpdateEntry $entry $true }
$form.Add_Shown({ Scan-JavaFolders })
[void]$form.ShowDialog()
