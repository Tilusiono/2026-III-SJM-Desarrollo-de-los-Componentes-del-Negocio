@echo off
setlocal
cd /d "%~dp0"
set "SED=%TEMP%\JavaHomeManager_%RANDOM%.sed"
set "TARGET=%CD%\JavaHomeManager.exe"
(
  echo [Version]
  echo Class=IEXPRESS
  echo SEDVersion=3
  echo [Options]
  echo PackagePurpose=InstallApp
  echo ShowInstallProgramWindow=1
  echo HideExtractAnimation=0
  echo UseLongFileName=1
  echo InsideCompressed=0
  echo CAB_FixedSize=0
  echo CAB_ResvCodeSigning=0
  echo RebootMode=N
  echo InstallPrompt=
  echo DisplayLicense=
  echo FinishMessage=
  echo TargetName=%TARGET%
  echo FriendlyName=Java Home Manager
  echo AppLaunched=cmd.exe /c Ejecutar_JavaHomeManager.cmd
  echo PostInstallCmd=^<None^>
  echo AdminQuietInstCmd=
  echo UserQuietInstCmd=
  echo SourceFiles=SourceFiles
  echo [SourceFiles]
  echo SourceFiles0=%CD%\
  echo [SourceFiles0]
  echo %%FILE0%%=
  echo %%FILE1%%=
  echo [Strings]
  echo FILE0="JavaHomeManager.ps1"
  echo FILE1="Ejecutar_JavaHomeManager.cmd"
) > "%SED%"

if not exist "%SystemRoot%\System32\iexpress.exe" (
  echo No se encontro IExpress en Windows.
  pause
  exit /b 1
)

"%SystemRoot%\System32\iexpress.exe" /N /Q "%SED%"
set "RESULT=%ERRORLEVEL%"
del "%SED%" >nul 2>&1
if not "%RESULT%"=="0" (
  echo No se pudo crear JavaHomeManager.exe.
  pause
  exit /b %RESULT%
)
echo.
echo Ejecutable creado correctamente:
echo %TARGET%
pause
