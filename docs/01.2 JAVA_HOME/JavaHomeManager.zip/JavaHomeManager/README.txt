JAVA HOME MANAGER
=================

REQUISITOS
- Windows 10 u 11.
- Windows PowerShell 5.1.
- Las instalaciones de Java pueden estar en C:\Program Files\Java.

EJECUCIÓN
1. Descomprime toda la carpeta.
2. Haz doble clic en Ejecutar_JavaHomeManager.cmd.
3. Acepta la solicitud de administrador de Windows.
4. La aplicación escaneará C:\Program Files\Java.

CREAR UN ARCHIVO .EXE
1. Haz doble clic en Crear_JavaHomeManager_EXE.cmd.
2. El proceso usa IExpress, incluido en Windows 10 y 11.
3. Se generará JavaHomeManager.exe en la misma carpeta.
4. El EXE contiene el script y el iniciador, y solicitará permisos de
   administrador al ejecutarse.

Si generaste un EXE con la versión anterior, elimínalo y vuelve a ejecutar
Crear_JavaHomeManager_EXE.cmd para incorporar estas correcciones.

FUNCIONES
- Detectar JDK y JRE por la existencia de bin\java.exe.
- Leer la versión desde el archivo release o desde java -version.
- Registrar manualmente una versión y su carpeta.
- Guardar los registros en:
  %LOCALAPPDATA%\JavaHomeManager\versions.json
- Cambiar JAVA_HOME para el sistema o para el usuario.
- Agregar %JAVA_HOME%\bin al inicio de Path cuando no existe.
- Mover la entrada al inicio cuando ya existe en una posición inferior.
- Mantener intactas las demás entradas de Path.
- Mostrar qué instalación coincide con JAVA_HOME.
- Validar JAVA_HOME, Path, where java, java -version y javac -version.
- Comparar la ruta ejecutada con la carpeta configurada.
- Copiar el diagnóstico completo desde una ventana de resultados.
- Quitar un registro sin borrar la carpeta de Java.

ALCANCE
- Sistema: aplica a todos los usuarios y requiere administrador.
- Usuario: aplica únicamente al usuario actual.

IMPORTANTE
- JAVA_HOME apunta a la carpeta raíz del JDK, por ejemplo:
  C:\Program Files\Java\jdk-17
- No debe apuntar a bin ni directamente a java.exe.
- Después de activar una versión, abre una terminal nueva.
- Comprueba el resultado con:
  echo %JAVA_HOME%
  java -version
  javac -version
  where java

VALIDACIÓN DESDE LA APLICACIÓN
Pulsa Validar versión para generar un diagnóstico. La ventana mostrará:
- JAVA_HOME del alcance seleccionado.
- Posición de %JAVA_HOME%\bin en Path.
- Ruta esperada y primera ruta devuelta por where java.
- Salida de java -version.
- Salida de javac -version.
- Código de salida de cada comando nativo.
- Ruta devuelta por Get-Command java.
- Resultado general y puntos que necesitan corrección.

La salida de java -version se escribe normalmente en stderr. La aplicación
la muestra como información cuando el código de salida es 0. Solo indica un
error real cuando el proceso devuelve un código distinto de 0.

COMPORTAMIENTO DE PATH
La aplicación busca la entrada literal %JAVA_HOME%\bin, ignorando mayúsculas,
minúsculas, comillas y la barra final. Si ya está en la primera posición, no
la duplica. Si aparece después de rutas antiguas de Oracle, la mueve al inicio.
Si no existe, la agrega al inicio sin borrar las demás entradas.

La ventana de Variables de entorno no se actualiza mientras permanece abierta.
Ciérrala y vuelve a abrirla después de activar otra versión.
